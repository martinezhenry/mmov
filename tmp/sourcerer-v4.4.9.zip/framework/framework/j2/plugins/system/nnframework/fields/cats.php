<?php
/**
 * Element: Cats
 * DEPRECATED!
 *
 * @package         NoNumber Framework
 * @version         15.2.11
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2015 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/content.php';

class JFormFieldNN_Cats extends JFormFieldNN_Content
{
}
